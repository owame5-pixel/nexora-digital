NEXORA DIGITAL WEBSITE

Files:
- index.html: the complete responsive one-page website.

Before publishing:
1. Open index.html in a text editor.
2. The enquiry form is configured to use moneymaker@nexoradigitals.com.
4. Review the introductory prices and services; change them if needed.
5. The portfolio projects are clearly labelled concepts, not real client work.
6. Publish using a free static hosting option only after checking its current terms.

Notes:
- The site uses plain HTML, CSS and JavaScript. No paid libraries or subscriptions are required.
- The enquiry form opens the visitor's email app. It does not store or send form submissions by itself.
- A custom domain, paid hosting, online booking/payment features or backend form processing may cost extra.
